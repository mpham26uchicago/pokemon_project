from tkinter import *
from Application import Application

# Creating a window from the application class
def main():
    root = Tk()
    root.title("Single Player Pokemon Battle")
    root.geometry("800x500")
    app = Application(root)
    root.mainloop()

main()
